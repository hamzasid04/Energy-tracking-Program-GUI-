package cpsc219p3.energytracker.p2;

/** *
 *
 * @author @hamza.siddiqui  Hamza Siddiqui, @marwah.ahmed@ucalgary.ca Marwah Ahmed
 * @UCID 30183881 , 30180880
 */

public class Main {
    public static void main(String[] args) {

        Menu.menuLoop();
    }
    
}
